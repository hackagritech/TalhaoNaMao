<?php
/*
 * Inwave_Video for Visual Composer
 */
if (!class_exists('Inwave_Video')) {

    class Inwave_Video extends Inwave_Shortcode{

        protected $name = 'inwave_video';

        function iframe_render( $video_url ) {
            $format = '<iframe src="%1$s" allowfullscreen class="video-embed"></iframe>';
            return sprintf($format, esc_url( $video_url ) );
        }

        function init_params() {
            return array(
                'name' => __("Video HTML", 'inwave-common'),
                'description' => __('Add a video HTML', 'inwave-common'),
                'base' => $this->name,
                'category' => 'Theme Custom',
                'icon' => 'iw-default',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Video Type",
                        "param_name" => "video_type",
                        "value" => array(
                            "Video Url in host" => "url",
                            "Video Youtube " => "youtube",
                            "Video Vimeo " => "vimeo",
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        "heading" => __("Video URL in host", 'inwave-common'),
                        "value" => "",
                        "param_name" => "video_url",
                        "dependency" => array('element' => 'video_type', 'value' => 'url')
                    ),
                    array(
                        'type' => 'textfield',
                        "heading" => __("Youtube Video ID", 'inwave-common'),
                        "value" => "",
                        "param_name" => "id_youtube",
                        'description'    => __( 'Example: the Video ID for https://www.youtube.com/watch?v=kJQP7kiw5Fk is ', 'inwave-common' ) .'<strong>kJQP7kiw5Fk</strong>',
                        "dependency" => array('element' => 'video_type', 'value' => 'youtube')
                    ),
                    array(
                        'type' => 'textfield',
                        "heading" => __("Vimeo Video ID", 'inwave-common'),
                        "value" => "",
                        "param_name" => "id_vimeo",
                        'description'    => __( 'Example: the Video ID for https://vimeo.com/162913890 is ', 'inwave-common' ) . '<strong>162913890</strong>',
                        "dependency" => array('element' => 'video_type', 'value' => 'vimeo')
                    ),
					array(
                        'type' => 'attach_image',
                        "heading" => __("Poster image", 'inwave-common'),
                        "param_name" => "video_poster",
                    ),
                    array(
                        'type' => 'colorpicker',
                        "heading" => __("Background Button", 'inwave-common'),
                        "value" => "",
                        "param_name" => "bg_button",
                    ),
                    array(
                        'type' => 'textfield',
                        "heading" => __("Text button", 'inwave-common'),
                        "value" => "",
                        "param_name" => "text_button",
                    ),
					array(
                        'type' => 'checkbox',
                        'heading' => __( 'Crop poster image?', 'js_composer' ),
                        'param_name' => 'crop_poster',
                    ),
					array(
                        'type' => 'textfield',
                        "heading" => __("Poster Image width", 'inwave-common'),
                        "value" => "800",
						"description" => __("Example: 800", 'inwave-common'),
                        "param_name" => "poster_width",
                    ),
					array(
                        'type' => 'textfield',
                        "heading" => __('Poster Image height ', 'inwave-common'),
                        "value" => "600",
						"description" => __('Example: 600.<br /> If "Crop poster image" is not checked, poster height is element height.', 'inwave-common'),
                        "param_name" => "poster_height",
                    ),
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {
            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $class = $style = $video_url = $video_poster = $bg_button = $text_button = $crop_poster = $poster_width = $poster_height = '';
            extract(shortcode_atts(array(
                'style' => '',
                'video_type' => '',
				'video_url' => '',
                'id_vimeo' => '',
                'id_youtube' => '',
				'video_poster' => '',
				'bg_button' => '',
				'text_button' =>'',
				'crop_poster' => '',
				'poster_height' => '',
				'poster_width' => '',
            ), $atts));

            $class_modal = 'modal fade';

            if ( $video_type == 'youtube' && !empty( $id_youtube ) ) {
                $video_url = 'https://www.youtube.com/embed/' . esc_attr( $id_youtube );
            }
            elseif ( $video_type == 'vimeo' && !empty( $id_vimeo ) ) {
                $video_url = 'https://player.vimeo.com/video/' . esc_attr( $id_vimeo ) . '?rel=0';
            }
            elseif( $video_type == 'url' && !empty( $video_url ) ){
                $video_url = $video_url;
            }

            if($video_poster){
                $video_poster = wp_get_attachment_image_src($video_poster, 'full');
                $video_poster = $video_poster[0];
                if ($crop_poster){
                    if ($poster_width && $poster_height){
                        $video_poster = inwave_resize($video_poster, $poster_width, $poster_height, true);
                    }
                }
                $element_css = 'style="';
                if ($poster_height){
                    $element_css .= 'height:'.$poster_height.'px;';
                } else {
                    $element_css .= 'height:800px;';
                }
                if ($poster_width){
                    $element_css .= 'width:'.$poster_width.'px;';
                } else {
                    $element_css .= 'width:100%;';
                    $class .= ' no-width';
                }
                $element_css .= '"';
            } else {
                $class .= ' no-poster';
            }

            if (!empty($video_url)) {
                $output .= '<div class="iw-video-html style1 '.$class.'">';
                $output .= '<div class="iw-video">';
                $id_modal_target = 'myModal'.rand(1,100);
                if($video_poster){
                    $output .= '<div class="video-poster" '.$element_css.'>';
                    $output .= '<div class="video-poster-inner" style="background-image: url('.esc_url($video_poster).');"></div>';
                    $output .= '<button type="button" class="open-popup-btn open-popup bt-video-effect" data-toggle="modal" data-target="#'.$id_modal_target.'"><i style="background:'.esc_attr__($bg_button).';" class="iwj-icon-play"></i><div class="text_button">'.$text_button.'</div></button>';
                    $output .=	'</div>';
                }
                //    $output .= '';
                $output .= '<div class="iw-video-player '.$class_modal.'" id="'.$id_modal_target.'" role="dialog">';
                $output .= '<div class="iw-modal-dialog">';
                if ( $video_type == 'url'){
                    $output .= '<div class="play-button bt-video-effect"><i style="background:'.esc_attr__($bg_button).';" class="ion-ios-play-outline"></i></div>';
                    $output .= '<div class="video"><video src="'.$video_url.'"></video></div>';
                }else{
                    $output .= '<div class="video">'.$this->iframe_render($video_url).'</div>';
                }
                $output .= '</div>';
                $output .= '</div>';

                $output .= '</div>';

                $output .= '</div>';
            }
            return $output;
        }
    }
}

new Inwave_Video;
