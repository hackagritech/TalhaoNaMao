jQuery(document).ready(function($) {
    $('.iw-tabs').iwTabs();
});