jQuery(document).ready(function($) {
    /* accordions */
    $(".iw-accordions").iwTabs("accordion");
});