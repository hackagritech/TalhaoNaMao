<?php

    $dashboard_url = iwj_get_page_permalink('dashboard');

    $user = IWJ_User::get_user();

    $employer = $user->get_employer(true);
    if ( is_user_logged_in() ) {

        global $current_user;
        $user_info = get_userdata($current_user->ID);
        $user = wp_get_current_user();


        $funcao ="";
        
        if ( in_array('administrator', (array) $user->roles )) {
            $funcao="adm";
        }
        if ( in_array('iwj_employer', (array) $user->roles )) {
            $funcao="usuario";
            $func = get_user_meta( $user->ID, 'tipo_de_usuario', true );
        }
        if ( in_array('customer', (array) $user->roles )) {
            //
        }

    }else {

        $url = home_url();
        wp_redirect( $url."/dashboard");
        exit();
    }

    if ($func == "calda" || $func == "almoxerife"  || $func == "aplicacao"){
        $tab= '';
        $tab = $_GET["iwj_tab"];
        if ($tab == "overview" || $tab == "" ){
        $url = 'http://talhao.escalepro.com.br/?iwj_tab=jobs';
        //wp_redirect($url);
        //exit();
        echo '<script>window.location.replace("http://talhao.escalepro.com.br/?iwj_tab=jobs");</script>';
        }
    }

?>

<div class="iwj-dashboard clearfix">



    <div class="iwj-dashboard-menu-mobile">

        <div class="dropdown">

            <?php

                $menu_title = IWJ_Front::tab_title();

                $menu_title = $menu_title ? $menu_title : __('Menu Dashboard', 'iwjob');

            ?>

            <button class="btn btn-primary dropdown-toggle"  type="button" data-toggle="dropdown"><?php echo $menu_title; ?> <span class="caret"></span></button>

            <?php iwj_get_template_part('dashboard-menu', array('tab' => $tab, 'attributes' => 'class="dropdown-menu" role="menu" aria-labelledby="dashboard-menu"'))?>

        </div>

    </div>



    <div class="iwj-dashboard-main <?php echo $tab; ?>">

        <div class="iwj-dashboard-main-inner">

            <?php do_action('iwj_message', $tab); ?>

            <?php if($employer && $employer->is_pending()){ ?>

                <div class="iwj-not-active">

                    <?php echo iwj_get_alert(__('Your profile is currently awaiting approval.', 'iwjob'), 'info'); ?>

                </div>

            <?php } ?>

            <?php echo $tab_content; ?>

        </div>

    </div>

    <!-- iwj-sidebar-sticky-->

    <div class="iwj-dashboard-sidebar">

        <div class="user-profile <?php echo (($user->get_candidate(true)) ? 'candidate' : ''); ?> clearfix">

            <?php

                echo get_avatar($user->get_id());

            ?>

            <h4>

                <span><?php echo __('Howdy!', 'iwjob');?></span>

                <?php echo $current_user->user_login;?>

            </h4>

        </div>

        <div class="iwj-dashboard-menu">

            <?php iwj_get_template_part('dashboard-menu', array('tab' => $tab, 'dashboard_menu' => true))?>

        </div>

    </div>

</div>