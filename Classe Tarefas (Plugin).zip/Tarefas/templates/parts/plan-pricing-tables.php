<?php if ($plans) {
    if ($atts['hide_free_plan']) $item = 3; else $item = 4;
    $data_plugin_options = array(
        "navigation"=>false,
        "paginationNumbers"=>false,
        "items"=>$item,
        "itemsDesktop"=>array( 1199,$item),
        "itemsDesktopSmall"=>array( 1199,3),
        "itemsTablet"=>array( 768,2),
        "itemsMobile"=>array( 600,1),
    );

    wp_enqueue_style('owl-carousel');
    wp_enqueue_style('owl-theme');
    wp_enqueue_style('owl-transitions');
    wp_enqueue_script('owl-carousel');
    $style = (isset($atts['style']) && $atts['style']) ?$atts['style']:'';

    ?>
    <?php switch ($style){
        case 'style1' :
            ?>
            <div class="iwj-pricing-tables <?php echo $atts['class']; echo $atts['style']; ?>">
                <div class="owl-carousel" data-plugin-options="<?php echo htmlspecialchars(json_encode($data_plugin_options)); ?>">
                    <?php
                    foreach ($plans as $plan){
                        $img_src = '';
                        $thumbnail_id = get_post_thumbnail_id($plan->get_id());
                        if($thumbnail_id){
                            $image = wp_get_attachment_image_src($bg_image, 'full');
                            if ( $image ) {
                                $img_src = $image[0];
                            }
                        }
                        if (!$img_src) {
                            $img_src = IWJ_PLUGIN_URL.'/assets/img/package_bg.png';
                        }

                        $pricing_table_color = get_post_meta($plan->get_id(), IWJ_PREFIX.'pricing_table_color', true);
                        if(!$pricing_table_color){
                            $pricing_table_color = '#34495E';
                        }

                        $active = $plan->is_active();

                        echo '<div class="pricing-item '.($plan->is_featured() ? 'featured-item' : '').' '.($active ? 'active-item' : '').'">';
                        echo '<div class="item-top" style="background-image: url('.$img_src.')">';
                        echo '<div class="item-top-bg" style=" background-color: '.$pricing_table_color.'"></div>';
                        echo '<div class="item-top-content">';
                        if($active){
                            echo '<span class="active-label">'.__('Active', 'iwjob').'</span>';
                        }
                        if ($plan->is_featured()) {
                            echo '<div class="star"><i class="ion-android-star"></i><i class="ion-android-star"></i><i class="ion-android-star"></i></div>';
                        }
                        if ($plan->get_sub_title()) {
                            echo '<div class="sub-title">'.$plan->get_sub_title().'</div>';
                        }
                        if ($plan->get_title()) {
                            echo '<h3 class="title"> '.$plan->get_title().'</h3>';
                        }
                        if ($plan->get_price()) {
                            echo '<div class="price"> '.iwj_system_price($plan->get_price()).'</div>';
                        }
                        echo '</div>';
                        echo '</div>';
                        echo '<div class="item-bottom">';
	                    $jobs = ( $plan->get_number_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_job();
	                    $features = ( $plan->get_number_featured_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_featured_job();
	                    $renews = ( $plan->get_number_renew_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_renew_job();
                        $max_cat = $plan->get_max_categories();
                        echo '<ul>';
                            echo '<li class="package-posting">'.sprintf(_n('<strong>%d</strong> Job posting', '<strong>%d</strong> Jobs posting', $jobs, 'iwjob'), $jobs).'</li>';
                            echo '<li class="package-features">'.sprintf(_n('<strong>%d</strong> Feature job', '<strong>%d</strong> Feature Jobs', $features, 'iwjob'), $features).'</li>';
                            echo '<li class="package-renews">'.sprintf(_n('<strong>%d</strong> Renew job', '<strong>%d</strong> Renew Jobs', $renews, 'iwjob'), $renews).'</li>';

                        $unit = $plan->get_expiry_unit();
                        $expiry = $plan->get_expiry();
                        if ($expiry) {
                            echo '<li class="package-duration">';
                            switch ($unit){
                                case 'day':
                                    echo sprintf(_n('<strong>%d</strong> Day duration', '<strong>%d</strong> Days duration', $expiry, 'iwjob'), $expiry);
                                    break;
                                case 'month':
                                    echo sprintf(_n('<strong>%d</strong> Month duration', '<strong>%d</strong> Months duration', $expiry, 'iwjob'), $expiry);
                                    break;
                                case 'year':
                                    echo sprintf(_n('<strong>%d</strong> Year duration', '<strong>%d</strong> Years duration', $expiry, 'iwjob'), $expiry);
                                    break;
                            }
                            echo '</li>';
                        }
                        if($max_cat){
                            echo '<li class="package-categories">'.sprintf(_n('<strong>%d</strong> Category', '<strong>%d</strong> Categories', $max_cat, 'iwjob'), $max_cat).'</li>';
                        }else{
                            echo '<li class="package-categories infinty">'.__('<strong class="ion-ios-infinite"></strong> Categories', 'iwjob').'</li>';
                        }
                        echo '</ul>';

                        if($active){
                            echo '<a class="buy-now" href="'.$plan->get_submit_job_url().'" style=" background-color: '.$pricing_table_color.'">'.__("Submit Now", 'iwjob').'</a>';
                        }else{
                            if($plan->is_free()){
                                echo '<a class="buy-now" href="'.$plan->get_buy_url().'" style=" background-color: '.$pricing_table_color.'">'.__("Choose Now", 'iwjob').'</a>';
                            }else{
                                echo '<a class="buy-now" href="'.$plan->get_buy_url().'" style=" background-color: '.$pricing_table_color.'">'.__("Buy Now", 'iwjob').'</a>';
                            }
                        }

                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
            <?php break;
        case 'style2' :
            ?>
            <div class="iwj-pricing-tables <?php echo $atts['class']; echo $atts['style']; ?>">
                <div class="owl-carousel" data-plugin-options="<?php echo htmlspecialchars(json_encode($data_plugin_options)); ?>">
                    <?php
                    foreach ($plans as $plan){

                        $type_package = $plan->get_type_package();

                        echo '<div class="pricing-item '.$type_package.'">';
                        echo '<div class="item-top text-center">';
                        echo '<div class="item-top-content">';

                        if ( $type_package == 'popular'){
                            echo '<div class="package_label">' . esc_html__( "Hot", "iwjob" ) . '</div>';
                        }
	                    if ( $plan->get_price() ) {
		                    echo '<div class="price"> ' . iwj_system_price( $plan->get_price() ) . '</div>';
	                    } else {
		                    echo '<div class="price"> ' . iwj_system_price( 0 ) . '</div>';
	                    }
	                    echo '</div>';

                        if ($plan->get_title()) {
                            echo '<h3 class="title"> '.$plan->get_title().'</h3>';
                        }

                        echo '</div>';
                        echo '<div class="item-bottom">';
                        $jobs = ( $plan->get_number_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_job();
                        $jobs_class = '';
	                    $features        = ( $plan->get_number_featured_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_featured_job();
	                    $renews          = ( $plan->get_number_renew_job() == - 1 ) ? __( 'Unlimited', 'iwjob' ) : $plan->get_number_renew_job();
                        $support_service = $plan->get_job_support();
                        echo '<ul>';
	                    if ( $jobs == 'Unlimited' ) {
		                    $jobs_class .= 'unlimited';
		                    echo '<li class="package-posting">'.esc_html__( 'Listing posting:', 'iwjob' ).'<span class="' . $jobs_class . '">' . esc_html__( 'Unlimited', 'iwjob' ) . '</span></li>';
	                    } else {
		                    echo '<li class="package-posting">'.esc_html__( 'Listing posting:', 'iwjob' ).' <span class="' . $jobs_class . '">' . esc_attr__( $jobs ) . '</span></li>';
	                    }
                        $unit = $plan->get_expiry_unit();
                        $expiry = $plan->get_expiry();
                        if ($expiry) {
                            echo '<li class="package-duration">';
                            switch ($unit){
                                case 'day':
                                    echo sprintf(_n('Duration: <span>%d Day</span>', 'Duration: <span>%d Days</span>', $expiry,  'iwjob'), $expiry);
                                    break;
                                case 'month':
                                    echo sprintf(_n('Duration: <span>%d Month</span>', 'Duration: <span>%d Months</span>', $expiry, 'iwjob'), $expiry);
                                    break;
                                case 'year':
                                    echo sprintf(_n('Duration: <span>%d Year</span>', 'Duration: <span>%d Years</span>', $expiry, 'iwjob'), $expiry);
                                    break;
                            }
                            echo '</li>';
                        }

	                    $listing_f_class = ( $features == 'Unlimited' ) ? 'unlimited' : '';
                        echo '<li class="package-features">'.sprintf(_n('Listing Feature: <span class="%s">%d</span>', 'Listing Feature: <span class="%s</span>', $features, 'iwjob'),$listing_f_class, $features).'</li>';

	                    $listing_renew_class = ( $renews == 'Unlimited' ) ? 'unlimited' : '';
                        if ($renews) {
                            echo '<li class="package-renews">' . sprintf(_n('Listing Renew: <span class="%s">%d</span>', 'Listing Renew: <span class="%s">%d</span>', $renews, 'iwjob'), $listing_renew_class,$renews) . '</li>';
                        } else {
                            echo '<li class="package-renews">'.esc_html__('Listing Renew: ', 'iwjob').'<span><i class="ion-android-cancel"></i></span></li>';
                        }
                        if($support_service){
                            echo '<li class="package-support">'.esc_html__('Support Service: ', 'iwjob').'<span>24/7</span></li>';
                        }else{
                            echo '<li class="package-support">'.esc_html__('Support Service: ', 'iwjob').'<span><i class="ion-android-cancel"></i></span></li>';
                        }
                        echo '</ul>';

                        echo '<div class="choose-package"><a class="buy-now" href="'.$plan->get_buy_url().'">'.esc_html__("Choose Package", 'iwjob').'</a></div>';

                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>
        <?php
            break;
    } ?>
<?php } ?>