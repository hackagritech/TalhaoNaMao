<div class="iwj-downloads iwj-main-block">
    <div class="iwj-table-overflow-x">
        <?php
        wc_get_template( 'myaccount/downloads.php' );
        ?>
    </div>
</div>