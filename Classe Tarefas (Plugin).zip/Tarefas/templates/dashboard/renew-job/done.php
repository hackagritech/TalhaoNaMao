<div class="iwj-done">
    <?php
    iwj_get_template_part('parts/thankyou-page');
    ?>
</div>