<div class="iwj-overview iwj-profile clearfix">

    <?php
    
    $dashboard_menu = isset( $dashboard_menu ) ? $dashboard_menu : false;

    echo $content; ?>

</div>



