<div class="iwj-profile clearfix">
    <?php echo $content; ?>
</div>