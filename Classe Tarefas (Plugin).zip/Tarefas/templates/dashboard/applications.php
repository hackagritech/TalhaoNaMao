<?php

$search            = isset( $_GET['search'] ) ? $_GET['search'] : '';

$paged             = isset( $_GET['cpage'] ) ? $_GET['cpage'] : '1';

$status            = isset( $_GET['status'] ) ? $_GET['status'] : '';

$job_id            = isset( $_GET['job-id'] ) ? $_GET['job-id'] : '';

$user              = IWJ_User::get_user();

$application_query = $user->get_applications();

$job_ids           = $user->get_job_ids();

$url               = iwj_get_page_permalink( 'dashboard' );

?>

<div class="iwj-applications iwj-main-block">

	<!--<div class="iwj-search-form">

		<form action="<?php echo $url; ?>">

			<span class="search-box">

                <input type="text" class="search-text" placeholder="<?php echo __( 'Search', 'iwjob' ); ?>" name="search" value="<?php echo esc_attr( $search ); ?>">

                <button class="search-button" type="submit"><i class="fa fa-search"></i></button>

            </span>

			<select class="search-select iwj-application-job iwj-select-2" name="job-id">

				<option value="" <?php selected( $job_id, '', false ); ?>><?php echo __( 'All Jobs', 'iwjob' ); ?></option>

				<?php

				foreach ( $job_ids as $_job_id ) {

					echo '<option value="' . $_job_id . '" ' . selected( $job_id, $_job_id, false ) . '>' . get_the_title( $_job_id ) . '</option>';

				}

				?>

			</select>

			<select class="search-select iwj-jobs-status iwj-select-2-wsearch" name="status">

				<option value="" <?php selected($status, ''); ?>><?php echo __('Status', 'iwjob'); ?></option>

				<?php

				$job_status = IWJ_Application::get_status_array(true, true);

				foreach ($job_status as $key=>$title){

					echo '<option value="'.$key.'" '.selected($status, $key, false).'>'.$title.'</option>';

				}

				?>

			</select>

			<input type="hidden" name="iwj_tab" value="applications">

		</form>

	</div>-->



	<div class="iwj-applications-table">

		<div class="iwj-table-overflow-x">

			<?php $tarefa_id = $_GET['tarefa'];


			$job = IWJ_Job::get_job(get_post($tarefa_id ));
			$author = $job->get_author();

			$get_more_details = $job->get_more_details();

			$user = IWJ_User::get_user();

			$job_sidebar = iwj_option('job_sidebar');

			wp_enqueue_script('google-maps');

			wp_enqueue_script('infobox');


			
			$job_details_version     = iwj_option( 'job_details_version', 'v1' );

			$template_detail_version = $job->get_template_detail_version();

			$details_versions        = $template_detail_version ? $template_detail_version : $job_details_version;

			?>



			<div class="contents-main iw-job-content iw-job-detail <?php echo esc_attr($details_versions); ?>" id="contents-main">

				<?php iwj_get_template_part( "parts/job-details/job-detail-" . $details_versions, array( 'user' => $user, 'job' => $job, 'author' => $author, 'job_sidebar' => $job_sidebar, 'get_more_details' => $get_more_details ) ); ?>

				<?php if ($job->has_status('draft')) { ?>

					<div class="iwj-job-action-btn">

						<a class="edit-job iwj-btn-shadow iwj-btn-icon iwj-btn-danger" href="<?php echo $job->edit_draft_link(); ?>"><?php echo __('<i class="ion-ios-compose"></i> Edit', 'iwjob'); ?></a>

						<a class="publish-job iwj-btn-shadow iwj-btn-icon iwj-btn-primary" href="<?php echo $job->publish_draft_link(); ?>"><?php echo __('<i class="ion-android-send"></i> Publish', 'iwjob'); ?></a>

					</div>

				<?php } ?>

			</div>
			<?php?>

		</div>

		<div class="modal fade iwj-application-view-modal" id="iwj-application-view-modal" tabindex="-1" role="dialog" data-loading="<?php echo __( 'Loading...', 'iwjob' ); ?>">

			<div class="modal-dialog" role="document">

				<div class="modal-content">

					<div class="modal-header">

						<h4 class="modal-title"><?php echo __( 'Application Details', 'iwjob' ); ?></h4>

						<button type="button" class="close" data-dismiss="modal" aria-label="Close">

							<span aria-hidden="true">&times;</span></button>

						<a class="print-button" href="javascript:window.print()" title="<?php _e( 'Print this page', 'iwjob' ); ?>"><i class="ion-android-print"></i></a>

					</div>

					<div class="modal-body">

						<?php echo __( 'Loading...', 'iwjob' ); ?>

					</div>

				</div>

			</div>

		</div>

		<?php if ( iwj_option( 'email_application_enable' ) ) {

			$application_emails = IWJ_Application::get_emails();

			?>

			<div class="modal fade" id="iwj-application-email-modal" tabindex="-1" role="dialog">

				<div class="modal-dialog" role="document">

					<div class="modal-content">

						<form class="iwj-application-email-form" action="<?php the_permalink(); ?>" method="post" enctype="multipart/form-data">

							<div class="modal-header">

								<h4 class="modal-title"><?php echo __( 'Send an email to candidate', 'iwjob' ); ?></h4>

								<button type="button" class="close" data-dismiss="modal" aria-label="Close">

									<span aria-hidden="true">&times;</span></button>

							</div>

							<div class="modal-body">

								<select name="email_type" id="application_email">

									<option value=""><?php echo __( 'Select A Letter Template', 'iwjob' ); ?></option>

									<?php foreach ( $application_emails as $email ) {

										echo '<option value="' . $email['id'] . '">' . $email['title'] . '</option>';

									} ?>

								</select>

								<textarea id="application_email_value" style="display: none"><?php echo json_encode( $application_emails ); ?></textarea>

								<input type="text" name="subject" placeholder="<?php echo __( 'Enter Email Subject', 'iwjob' ); ?>" value="">

								<?php

								iwj_field_wysiwyg( 'message', '', true, '', '', '', __( 'You can use tags: #employer_name#, #employer_email#, #candidate_name#, #candidate_email#', 'iwjob' ), 'Enter Email Message', array(

									'quicktags'     => false,

									'editor_height' => 250

								) );

								?>

							</div>

							<div class="iwj-respon-msg iwj-hide"></div>

							<div class="modal-footer">

								<input type="hidden" name="application_id" value="">

								<div class="iwj-button-loader">

									<button class="iwj-btn iwj-btn-primary iwj-application-email-btn"><?php echo __( 'Send', 'iwjob' ); ?></button>

								</div>

								<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo __( 'Cancel' ); ?></button>

							</div>

						</form>

					</div>

				</div>

			</div>

		<?php } ?>

		<?php

		if ( iwj_option( 'employer_can_delete_application' ) ) { ?>

			<div class="modal fade" id="iwj-confirm-delete-application" role="dialog">

				<div class="modal-dialog">

					<!-- Modal content-->

					<div class="modal-content">

						<div class="modal-header">

							<h4 class="modal-title"><?php echo __( 'Confirm Delete', 'iwjob' ); ?></h4>

							<button type="button" class="close" data-dismiss="modal" aria-label="Close">

								<span aria-hidden="true">&times;</span></button>

						</div>

						<div class="modal-body">

							<p></p>

						</div>

						<div class="modal-footer">

							<div class="iwj-respon-msg"></div>

							<div class="iwj-button-loader">

								<button type="button" class="btn btn-primary iwj-agree-delete-application"><?php echo __( 'Continue', 'iwjob' ); ?></button>

								<button type="button" class="btn btn-default" data-dismiss="modal"><?php echo __( 'Close', 'iwjob' ); ?></button>

							</div>

						</div>

					</div>

				</div>

			</div>

		<?php } ?>

	</div>

	<div class="clearfix"></div>

	<?php

	if ( $application_query && $application_query->max_num_pages > 1 ) { ?>

		<div class="iwj-pagination">

			<?php

			$big = 999999999; // need an unlikely integer

			echo paginate_links( array(

				'base'      => add_query_arg( 'cpage', '%#%' ),

				'format'    => '',

				'prev_text' => __( '&laquo;' ),

				'next_text' => __( '&raquo;' ),

				'current'   => $paged,

				'total'     => $application_query->max_num_pages

			) );

			?>

		</div>

		<div class="clearfix"></div>

	<?php } ?>

</div>

