<?php

$attributes    = isset( $attributes ) ? $attributes : '';

//dashboard menu or topbar menu

$dashboard_menu = isset( $dashboard_menu ) ? $dashboard_menu : false;

if ( is_user_logged_in() ) {

    global $current_user;
    $user_info = get_userdata($current_user->ID);
    $user = wp_get_current_user();


    $funcao ="";
    
    if ( in_array('administrator', (array) $user->roles )) {
        $funcao="adm";
    }
    if ( in_array('iwj_employer', (array) $user->roles )) {
        $funcao="usuario";
        $func = get_user_meta( $user->ID, 'tipo_de_usuario', true );
    }
    if ( in_array('customer', (array) $user->roles )) {
        //
    }

}else {

    $url = home_url();
    wp_redirect( $url."/dashboard");
}


if(isset( $dashboard_menu ) && $dashboard_menu){

    $show_on_position = 1;

}elseif(isset($attributes) && $attributes){

    $show_on_position = 2;

}else{

    $show_on_position = 3;

}



$dashboard_menus = iwj_get_dashboard_menus($show_on_position);

?>



<ul <?php echo $attributes; ?>>

    <?php do_action('iwj_before_dashboard_menu', $tab, $show_on_position); ?>

    <?php

    if($dashboard_menus){
        $tabs=[];
        foreach($dashboard_menus as $tab_key=>$dashboard_menu){


            if ($funcao =="adm"){
                ?>
    
                <li <?php echo $tab == $tab_key ? 'class="active"' : ''; ?>>
    
                    <a href="<?php echo esc_url($dashboard_menu['url']); ?>"><?php echo $dashboard_menu['title']; ?></a>
    
                </li>
    
                <?php
                
            }
        
            else{

            if ($dashboard_menu['url'] == "http://talhao.escalepro.com.br/?iwj_tab=overview" ){
                if ($func == "gestor" || $func == "tecnico"){?>

            <li <?php echo $tab == $tab_key ? 'class="active"' : ''; ?>>

                <a href="<?php echo esc_url($dashboard_menu['url']); ?>"><?php echo $dashboard_menu['title']; ?></a>

            </li>

            <?php
                }
            }
            if ($dashboard_menu['url'] == "http://talhao.escalepro.com.br/?iwj_tab=new-job" ){
                if ($func == "gestor" || $func == "tecnico"){?>

            <li <?php echo $tab == $tab_key ? 'class="active"' : ''; ?>>

                <a href="<?php echo esc_url($dashboard_menu['url']); ?>"><?php echo $dashboard_menu['title']; ?></a>

            </li>

            <?php
            }
            }
            if ($dashboard_menu['url'] == "http://talhao.escalepro.com.br/?iwj_tab=jobs"){
                if ($func == "gestor" || $func == "tecnico"){?>

                <li <?php echo $tab == $tab_key ? 'class="active"' : ''; ?>>
    
                    <a href="<?php echo esc_url($dashboard_menu['url']); ?>"><?php echo $dashboard_menu['title']; ?></a>
    
                </li>
                
    
                <?php
                }
            }
            if ($dashboard_menu['url'] == "http://talhao.escalepro.com.br/?iwj_tab=jobs"){
                if ($func == "calda" || $func == "almoxerife"  || $func == "aplicacao"){?>

                <li <?php $tabs[] = "tarefas"; echo $tab == $tab_key ? 'class="active"' : ''; ?>>
    
                    <a href="<?php echo esc_url($dashboard_menu['url']); ?>"><?php echo "Minhas Tarefas"; ?></a>
    
                </li>
                
    
                <?php
                }
            }
            }   

            

        }

    }

    ?>

    <?php do_action('iwj_after_dashboard_menu', $tab, $show_on_position); ?>

</ul>