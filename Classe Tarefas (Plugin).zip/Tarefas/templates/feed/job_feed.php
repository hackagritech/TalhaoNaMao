<?php
/**
 * RSS2 Feed Template for displaying RSS2 Posts feed.
 *
 * @package WordPress
 */

header('Content-Type: ' . feed_content_type('rss2') . '; charset=' . get_option('blog_charset'), true);
$more = 1;

echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>';

/**
 * Fires between the xml and rss tags in a feed.
 *
 * @since 4.0.0
 *
 * @param string $context Type of feed. Possible values include 'rss2', 'rss2-comments',
 *                        'rdf', 'atom', and 'atom-comments'.
 */
do_action( 'rss_tag_pre', 'rss2' );
?>
<rss version="2.0"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:atom="http://www.w3.org/2005/Atom"
	xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
	xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
	<?php
	/**
	 * Fires at the end of the RSS root to add namespaces.
	 *
	 * @since 2.0.0
	 */
	do_action( 'rss2_ns' );
	?>
>

<channel>
	<title><?php wp_title_rss(); ?></title>
	<atom:link href="<?php self_link(); ?>" rel="self" type="application/rss+xml" />
	<link><?php bloginfo_rss('url') ?></link>
	<description><?php bloginfo_rss("description") ?></description>
	<lastBuildDate><?php
		$date = get_lastpostmodified( 'GMT' );
		echo $date ? mysql2date( 'r', $date, false ) : date_i18n( 'r' );
	?></lastBuildDate>
	<language><?php bloginfo_rss( 'language' ); ?></language>
	<sy:updatePeriod><?php
		$duration = 'hourly';

		/**
		 * Filters how often to update the RSS feed.
		 *
		 * @since 2.1.0
		 *
		 * @param string $duration The update period. Accepts 'hourly', 'daily', 'weekly', 'monthly',
		 *                         'yearly'. Default 'hourly'.
		 */
		echo apply_filters( 'rss_update_period', $duration );
	?></sy:updatePeriod>
	<sy:updateFrequency><?php
		$frequency = '1';

		/**
		 * Filters the RSS update frequency.
		 *
		 * @since 2.1.0
		 *
		 * @param string $frequency An integer passed as a string representing the frequency
		 *                          of RSS updates within the update period. Default '1'.
		 */
		echo apply_filters( 'rss_update_frequency', $frequency );
	?></sy:updateFrequency>
	<?php
	/**
	 * Fires at the end of the RSS2 Feed Header.
	 *
	 * @since 2.0.0
	 */
	do_action( 'rss2_head');
    $data_ajax_filter = IWJ_Job_Listing::get_data_filters();
    $query = IWJ_Job_Listing::get_query_jobs($data_ajax_filter);
	while( $query->have_posts()) : $query->the_post();
	$post = get_post();
	$job = IWJ_Job::get_job($post);
	$author = $job->get_author();
	$category_titles = iwj_get_terms_value($job->get_categories());
	$type = $job->get_type();
	$level_titles = iwj_get_terms_value($job->get_all_levels());
	$skill_titles = iwj_get_terms_value($job->get_all_skills());
	$locations = $job->get_locations();
    $locations = $locations ? array_reverse($locations) : '';
	$locations_titles = iwj_get_terms_value($locations);
	?>
	<item>
		<title><?php echo $job->get_title(); ?></title>
		<link><?php echo $job->permalink(); ?></link>
        <pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
		<company><![CDATA[<?php echo $author->get_display_name(); ?>]]></company>
        <category><![CDATA[<?php echo $category_titles ? implode("|", $category_titles) : ""; ?>]]></category>
        <type><![CDATA[<?php echo $type ? $type->name : ''; ?>]]></type>
        <level><![CDATA[<?php echo $level_titles ? implode("|", $level_titles) : ""; ?>]]></level>
        <skill><![CDATA[<?php echo $skill_titles ? implode("|", $skill_titles) : ""; ?>]]></skill>
        <location><![CDATA[<?php echo $locations_titles ? implode("|", $locations_titles) : ""; ?>]]></location>
        <address><![CDATA[<?php echo $job->get_address(); ?>]]></address>
        <salary><![CDATA[<?php echo $job->get_salary().($job->get_salary_postfix() ? ' \\ '.$job->get_salary_postfix() : ""); ?>]]></salary>
        <description><![CDATA[<?php echo $job->get_description(); ?>]]></description>
    <?php rss_enclosure(); ?>
	<?php
	/**
	 * Fires at the end of each RSS2 feed item.
	 *
	 * @since 2.0.0
	 */
	do_action( 'rss2_item' );
	?>
	</item>
	<?php endwhile; ?>
</channel>
</rss>
