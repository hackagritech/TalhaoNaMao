/* 
 * @package Inwave Job
 * @version 1.0.0
 * @created Jun 2, 2016
 * @author Inwavethemes
 * @email inwavethemes@gmail.com
 * @website http://inwavethemes.com
 * @support Ticket https://inwave.ticksy.com/
 * @copyright Copyright (c) 2015 Inwavethemes. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

/**
 * Description of injob-script
 *
 * @developer Hien Tran
 */

(function ($) {
    'use strict';
    $(document).ready(function ($) {

        window.onscroll = function () {
            myFunction()
        };

        var detail_menu = $(".employer-info-top-wrap");
        var sticky = detail_menu.offset().top;

        function myFunction() {
            if (window.pageYOffset >= sticky) {
                detail_menu.addClass("sticky");
            } else {
                detail_menu.removeClass("sticky");
            }
        }
    });

    $(document).ready(function () {
        // Video employer
        if ($('.iwj-employer-detail-video').length) {
            var video = $(".iwj-employer-detail-video");
            video.on("click", function () {

                var iframe = document.createElement("iframe");

                iframe.setAttribute("id", "iwj-employer-detail-video");
                iframe.setAttribute("frameborder", "0");
                iframe.setAttribute("allowfullscreen", "");
                iframe.setAttribute("width", "770");
                iframe.setAttribute("height", "435");
                iframe.setAttribute("src", this.dataset.embed + "?rel=0&showinfo=0");

                video.find('.play-button').hide();
                video.find('.video-container').html(iframe);
            });
        }

        var owl = $('.owl-carousel-gallery');
        owl.owlCarousel({
            items: 1,
            loop: true,
            center: true,
            onTranslated: function(event){
                if(event.page.index > 0){
                    var video = $(".iwj-employer-detail-video");
                    video.find('.play-button').show();
                    video.find('.play-button').show();
                    video.find('.video-container').html('');
                }
            }
        });
    });



})(jQuery);